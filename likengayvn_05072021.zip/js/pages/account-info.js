$('.j-password').click(function () {
    $('#container').load("components/reset-password.html");
});